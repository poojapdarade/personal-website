import { PageLayout } from "../components/PageLayout";

export function Contact() {
  return <PageLayout title="Hello"></PageLayout>;
}
